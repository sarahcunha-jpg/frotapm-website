
  # Police Fleet Management System

  This is a code bundle for Police Fleet Management System. The original project is available at https://www.figma.com/design/EqVQUqADcbYGM3Y6xjF9jN/Police-Fleet-Management-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  