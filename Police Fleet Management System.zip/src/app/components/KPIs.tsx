import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import { AreaChart, Area, BarChart, Bar, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { viaturas, ordensServico, manutencoesMensais } from "../data/mockData";

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload?.length) {
    return (
      <div className="bg-popover border border-border rounded-md px-3 py-2 text-xs shadow-lg">
        <p className="text-muted-foreground mb-1">{label}</p>
        {payload.map((p: any) => <p key={p.name} style={{ color: p.color }}>{p.name}: <span className="text-foreground font-medium">{p.value}</span></p>)}
      </div>
    );
  }
  return null;
};

function KpiCard({ title, value, unit, formula, trend, desc, color }: {
  title: string; value: string; unit: string; formula: string; trend: "up" | "down" | "neutral"; desc: string; color: string;
}) {
  const TrendIcon = trend === "up" ? TrendingUp : trend === "down" ? TrendingDown : Minus;
  const trendColor = trend === "up" ? "text-emerald-400" : trend === "down" ? "text-red-400" : "text-muted-foreground";
  return (
    <div className="bg-card border border-border rounded-xl p-5 hover:border-border/80 transition-colors">
      <p className="text-xs text-muted-foreground uppercase tracking-widest mb-3">{title}</p>
      <div className="flex items-end gap-2 mb-3">
        <span className="text-4xl font-bold mono" style={{ fontFamily: "DM Mono, monospace", color }}>{value}</span>
        <span className="text-muted-foreground text-sm mb-1">{unit}</span>
        <TrendIcon size={14} className={`${trendColor} mb-1.5 ml-auto`} />
      </div>
      <p className="text-xs text-muted-foreground mb-3">{desc}</p>
      <div className="bg-muted/30 rounded-md px-3 py-2">
        <p className="text-xs text-muted-foreground mono" style={{ fontFamily: "DM Mono, monospace" }}>{formula}</p>
      </div>
    </div>
  );
}

export default function KPIs() {
  const total = viaturas.length;
  const disponiveis = viaturas.filter(v => v.status === "operação").length;
  const disponibilidade = Math.round((disponiveis / total) * 100);

  const finalizadas = ordensServico.filter(o => o.status === "finalizada");
  const mttr = finalizadas.length > 0 ? (finalizadas.reduce((a, o) => a + o.tempoParada, 0) / finalizadas.length).toFixed(1) : "0";

  const custoTotal = ordensServico.reduce((a, o) => a + o.custo, 0);
  const custoPorViatura = Math.round(custoTotal / total);

  const corretivas = ordensServico.filter(o => o.status === "finalizada" && o.custo > 1500).length;
  const mtbf = corretivas > 0 ? Math.round((87450 / corretivas)).toLocaleString("pt-BR") : "—";

  const custoMensal = manutencoesMensais.map(m => ({ mes: m.mes, custo: m.custo }));

  const eficiencia = [
    { mes: "Jan", disponibilidade: 86, meta: 85 },
    { mes: "Fev", disponibilidade: 80, meta: 85 },
    { mes: "Mar", disponibilidade: 91, meta: 85 },
    { mes: "Abr", disponibilidade: 84, meta: 85 },
    { mes: "Mai", disponibilidade: 88, meta: 85 },
    { mes: "Jun", disponibilidade: 80, meta: 85 },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "Roboto Slab, serif" }}>Indicadores de Desempenho</h1>
        <p className="text-muted-foreground text-xs mt-0.5">KPIs operacionais da frota — período: Jan–Jun 2025</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          title="Disponibilidade da Frota"
          value={String(disponibilidade)}
          unit="%"
          formula={`(${disponiveis} ÷ ${total}) × 100`}
          trend={disponibilidade >= 85 ? "up" : "down"}
          desc={`${disponiveis} de ${total} viaturas disponíveis`}
          color="#1d6cf0"
        />
        <KpiCard
          title="MTTR — Tempo Médio de Reparo"
          value={mttr}
          unit="dias"
          formula="Σ tempo_reparo ÷ Nº reparos"
          trend="neutral"
          desc={`Baseado em ${finalizadas.length} OS finalizadas`}
          color="#f59e0b"
        />
        <KpiCard
          title="MTBF — Tempo Entre Falhas"
          value={mtbf}
          unit="km"
          formula="KM operação ÷ Nº falhas"
          trend="up"
          desc="Intervalo médio entre ocorrências"
          color="#10b981"
        />
        <KpiCard
          title="Custo por Viatura"
          value={`R$ ${custoPorViatura.toLocaleString("pt-BR")}`}
          unit=""
          formula={`R$ ${custoTotal.toLocaleString("pt-BR")} ÷ ${total} viaturas`}
          trend={custoPorViatura < 3000 ? "up" : "down"}
          desc="Custo médio de manutenção 2025"
          color="#8b5cf6"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-card border border-border rounded-xl p-5">
          <h3 className="text-sm font-semibold text-foreground mb-5" style={{ fontFamily: "Roboto Slab, serif" }}>Disponibilidade vs Meta (85%)</h3>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={eficiencia}>
              <defs>
                <linearGradient id="kpiGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#1d6cf0" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#1d6cf0" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="2 4" stroke="rgba(148,163,184,0.06)" />
              <XAxis dataKey="mes" tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis domain={[70, 100]} tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="disponibilidade" name="Disponibilidade %" stroke="#1d6cf0" fill="url(#kpiGrad)" strokeWidth={2} />
              <Area type="monotone" dataKey="meta" name="Meta %" stroke="#f59e0b" fill="none" strokeWidth={1.5} strokeDasharray="4 2" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-card border border-border rounded-xl p-5">
          <h3 className="text-sm font-semibold text-foreground mb-5" style={{ fontFamily: "Roboto Slab, serif" }}>Custo Mensal de Manutenção (R$)</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={custoMensal}>
              <CartesianGrid strokeDasharray="2 4" stroke="rgba(148,163,184,0.06)" />
              <XAxis dataKey="mes" tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `${(v / 1000).toFixed(0)}k`} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="custo" name="Custo R$" fill="#8b5cf6" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-card border border-border rounded-xl p-5">
        <h3 className="text-sm font-semibold text-foreground mb-4" style={{ fontFamily: "Roboto Slab, serif" }}>Resumo por Unidade</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                {["Unidade", "Total Viaturas", "Em Operação", "Em Manutenção", "Disponibilidade"].map(h => (
                  <th key={h} className="text-left text-xs text-muted-foreground font-medium px-4 py-2 uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {["10º BPM – Centro", "1ª CIPM – Garcia", "2ª CIPM – Velha", "3ª CIPM – Itoupava", "4ª CIPM – Ponta Aguda", "5ª CIPM – Fortaleza", "Comando BPTUR"].map((unidade) => {
                const uvs = viaturas.filter(v => v.unidade === unidade);
                const uOp = uvs.filter(v => v.status === "operação").length;
                const uMan = uvs.filter(v => v.status !== "operação").length;
                const uDisp = uvs.length > 0 ? Math.round((uOp / uvs.length) * 100) : 0;
                return (
                  <tr key={unidade} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                    <td className="px-4 py-3 text-foreground text-xs">{unidade}</td>
                    <td className="px-4 py-3 mono text-center" style={{ fontFamily: "DM Mono, monospace" }}>{uvs.length}</td>
                    <td className="px-4 py-3 mono text-emerald-400 text-center" style={{ fontFamily: "DM Mono, monospace" }}>{uOp}</td>
                    <td className="px-4 py-3 mono text-amber-400 text-center" style={{ fontFamily: "DM Mono, monospace" }}>{uMan}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-muted rounded-full h-1.5">
                          <div className="h-1.5 rounded-full transition-all" style={{ width: `${uDisp}%`, background: uDisp >= 85 ? "#10b981" : uDisp >= 70 ? "#f59e0b" : "#ef4444" }} />
                        </div>
                        <span className="mono text-xs w-10" style={{ fontFamily: "DM Mono, monospace", color: uDisp >= 85 ? "#10b981" : "#f59e0b" }}>{uDisp}%</span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
