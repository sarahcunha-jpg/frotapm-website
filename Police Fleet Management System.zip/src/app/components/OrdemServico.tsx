import { useState } from "react";
import { Plus, X, FileText, CheckSquare, Clock, AlertCircle, Printer } from "lucide-react";
import { OrdemServico as OS, OSStatus, ordensServico as initialOS, viaturas } from "../data/mockData";

const STATUS_CONFIG: Record<OSStatus, { label: string; color: string; bg: string }> = {
  aberta: { label: "Aberta", color: "text-sky-400", bg: "bg-sky-500/10 border-sky-500/20" },
  andamento: { label: "Em Andamento", color: "text-amber-400", bg: "bg-amber-500/10 border-amber-500/20" },
  finalizada: { label: "Finalizada", color: "text-emerald-400", bg: "bg-emerald-500/10 border-emerald-500/20" },
};

const RESPONSAVEIS = ["Sgt. Pereira", "Cb. Santos", "Of. Lima", "Sgt. Rodrigues"];

export default function OrdemServico() {
  const [orders, setOrders] = useState<OS[]>(initialOS);
  const [filter, setFilter] = useState<OSStatus | "todos">("todos");
  const [modal, setModal] = useState<"add" | "view" | null>(null);
  const [selected, setSelected] = useState<OS | null>(null);
  const [form, setForm] = useState({ viaturaId: viaturas[0].id, problema: "", servico: "", responsavel: RESPONSAVEIS[0], pecas: "", custo: "", tempoParada: "" });

  const filtered = filter === "todos" ? orders : orders.filter(o => o.status === filter);
  const counts = { aberta: orders.filter(o => o.status === "aberta").length, andamento: orders.filter(o => o.status === "andamento").length, finalizada: orders.filter(o => o.status === "finalizada").length };

  function handleAdd() {
    if (!form.problema || !form.servico) return;
    const v = viaturas.find(v => v.id === form.viaturaId)!;
    const newOS: OS = {
      id: `os${Date.now()}`, numero: `OS-2025-${String(orders.length + 1).padStart(3, "0")}`,
      data: new Date().toISOString().split("T")[0], viaturaId: form.viaturaId,
      viatura: `${v.numero} – ${v.placa} ${v.modelo}`, problema: form.problema,
      servico: form.servico, responsavel: form.responsavel, pecas: form.pecas,
      custo: Number(form.custo), tempoParada: Number(form.tempoParada), status: "aberta",
    };
    setOrders(o => [newOS, ...o]);
    setModal(null);
    setForm({ viaturaId: viaturas[0].id, problema: "", servico: "", responsavel: RESPONSAVEIS[0], pecas: "", custo: "", tempoParada: "" });
  }

  function handleFinalize(id: string) { setOrders(o => o.map(os => os.id === id ? { ...os, status: "finalizada" } : os)); setModal(null); }
  function handleAdvance(id: string) { setOrders(o => o.map(os => os.id === id && os.status === "aberta" ? { ...os, status: "andamento" } : os)); }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "Roboto Slab, serif" }}>Ordens de Serviço</h1>
          <p className="text-muted-foreground text-xs mt-0.5">{orders.length} ordens no total</p>
        </div>
        <button onClick={() => setModal("add")} className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-md text-sm font-medium hover:bg-primary/90 transition-colors">
          <Plus size={15} /> Abrir OS
        </button>
      </div>

      <div className="grid grid-cols-3 gap-3">
        {([["aberta", FileText, "Abertas"], ["andamento", Clock, "Em Andamento"], ["finalizada", CheckSquare, "Finalizadas"]] as const).map(([key, Icon, label]) => (
          <button key={key} onClick={() => setFilter(f => f === key ? "todos" : key)} className={`flex items-center gap-3 p-4 rounded-lg border transition-colors text-left ${filter === key ? "border-primary/40 bg-primary/10" : "border-border bg-card hover:border-border/80"}`}>
            <Icon size={16} className={STATUS_CONFIG[key].color} />
            <div>
              <p className="text-muted-foreground text-xs">{label}</p>
              <p className="text-2xl font-bold mono" style={{ fontFamily: "DM Mono, monospace", color: filter === key ? "#1d6cf0" : "#e2e8f0" }}>{counts[key]}</p>
            </div>
          </button>
        ))}
      </div>

      <div className="space-y-2">
        {filtered.map(os => {
          const cfg = STATUS_CONFIG[os.status];
          return (
            <div key={os.id} className="bg-card border border-border rounded-lg p-4 hover:border-border/80 transition-colors cursor-pointer" onClick={() => { setSelected(os); setModal("view"); }}>
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className="mt-0.5">
                    <AlertCircle size={15} className={cfg.color} />
                  </div>
                  <div>
                    <div className="flex items-center gap-3 mb-1">
                      <span className="font-semibold mono text-foreground text-sm" style={{ fontFamily: "DM Mono, monospace" }}>{os.numero}</span>
                      <span className={`inline-flex px-2 py-0.5 rounded text-xs border ${cfg.bg} ${cfg.color}`}>{cfg.label}</span>
                    </div>
                    <p className="text-foreground text-sm mb-0.5">{os.viatura}</p>
                    <p className="text-muted-foreground text-xs">{os.problema}</p>
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="mono text-foreground font-medium" style={{ fontFamily: "DM Mono, monospace" }}>R$ {os.custo.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
                  <p className="text-muted-foreground text-xs">{os.data}</p>
                  <p className="text-muted-foreground text-xs">{os.responsavel}</p>
                </div>
              </div>
            </div>
          );
        })}
        {filtered.length === 0 && <div className="text-center py-12 text-muted-foreground text-sm">Nenhuma ordem encontrada.</div>}
      </div>

      {modal === "add" && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-card border border-border rounded-xl w-full max-w-xl shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between px-6 py-4 border-b border-border sticky top-0 bg-card">
              <h2 className="font-bold text-foreground" style={{ fontFamily: "Roboto Slab, serif" }}>Abrir Ordem de Serviço</h2>
              <button onClick={() => setModal(null)} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block">viatura</label>
                <select value={form.viaturaId} onChange={e => setForm(f => ({ ...f, viaturaId: e.target.value }))} className="w-full bg-input-background border border-border rounded-md px-3 py-2 text-sm text-foreground outline-none focus:border-primary/50">
                  {viaturas.map(v => <option key={v.id} value={v.id}>{v.numero} – {v.placa} {v.modelo}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block">problema identificado</label>
                <textarea value={form.problema} onChange={e => setForm(f => ({ ...f, problema: e.target.value }))} rows={2} className="w-full bg-input-background border border-border rounded-md px-3 py-2 text-sm text-foreground outline-none focus:border-primary/50 resize-none" />
              </div>
              <div>
                <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block">serviço a executar</label>
                <textarea value={form.servico} onChange={e => setForm(f => ({ ...f, servico: e.target.value }))} rows={2} className="w-full bg-input-background border border-border rounded-md px-3 py-2 text-sm text-foreground outline-none focus:border-primary/50 resize-none" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block">responsável</label>
                  <select value={form.responsavel} onChange={e => setForm(f => ({ ...f, responsavel: e.target.value }))} className="w-full bg-input-background border border-border rounded-md px-3 py-2 text-sm text-foreground outline-none focus:border-primary/50">
                    {RESPONSAVEIS.map(r => <option key={r} value={r}>{r}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block">custo estimado (R$)</label>
                  <input type="number" value={form.custo} onChange={e => setForm(f => ({ ...f, custo: e.target.value }))} className="w-full bg-input-background border border-border rounded-md px-3 py-2 text-sm text-foreground outline-none focus:border-primary/50" />
                </div>
              </div>
              <div>
                <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block">peças utilizadas</label>
                <input value={form.pecas} onChange={e => setForm(f => ({ ...f, pecas: e.target.value }))} className="w-full bg-input-background border border-border rounded-md px-3 py-2 text-sm text-foreground outline-none focus:border-primary/50" placeholder="Ex: Pastilhas de freio, fluido DOT4" />
              </div>
              <div>
                <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block">tempo de parada (dias)</label>
                <input type="number" value={form.tempoParada} onChange={e => setForm(f => ({ ...f, tempoParada: e.target.value }))} className="w-full bg-input-background border border-border rounded-md px-3 py-2 text-sm text-foreground outline-none focus:border-primary/50" />
              </div>
            </div>
            <div className="flex justify-end gap-3 px-6 py-4 border-t border-border">
              <button onClick={() => setModal(null)} className="px-4 py-2 rounded-md text-sm text-muted-foreground border border-border hover:border-foreground/20 transition-colors">Cancelar</button>
              <button onClick={handleAdd} className="px-4 py-2 rounded-md text-sm bg-primary text-primary-foreground hover:bg-primary/90 font-medium transition-colors">Abrir OS</button>
            </div>
          </div>
        </div>
      )}

      {modal === "view" && selected && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-card border border-border rounded-xl w-full max-w-xl shadow-2xl">
            <div className="flex items-center justify-between px-6 py-4 border-b border-border">
              <div>
                <span className="font-bold text-foreground mono" style={{ fontFamily: "DM Mono, monospace" }}>{selected.numero}</span>
                <span className={`ml-3 inline-flex px-2 py-0.5 rounded text-xs border ${STATUS_CONFIG[selected.status].bg} ${STATUS_CONFIG[selected.status].color}`}>{STATUS_CONFIG[selected.status].label}</span>
              </div>
              <button onClick={() => setModal(null)} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                {[["Data", selected.data], ["Viatura", selected.viatura], ["Responsável", selected.responsavel], ["Tempo de Parada", `${selected.tempoParada} dia(s)`], ["Custo", `R$ ${selected.custo.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`]].map(([k, v]) => (
                  <div key={k}>
                    <p className="text-xs text-muted-foreground uppercase tracking-wider mb-0.5">{k}</p>
                    <p className="text-foreground font-medium">{v}</p>
                  </div>
                ))}
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Problema Identificado</p>
                <p className="text-foreground text-sm bg-muted/30 rounded-md p-3">{selected.problema}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Serviço Executado</p>
                <p className="text-foreground text-sm bg-muted/30 rounded-md p-3">{selected.servico}</p>
              </div>
              {selected.pecas && (
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Peças Utilizadas</p>
                  <p className="text-foreground text-sm bg-muted/30 rounded-md p-3">{selected.pecas}</p>
                </div>
              )}
            </div>
            <div className="flex items-center gap-3 px-6 py-4 border-t border-border">
              <button className="flex items-center gap-2 text-muted-foreground hover:text-foreground text-sm border border-border px-3 py-1.5 rounded-md transition-colors">
                <Printer size={14} /> Imprimir
              </button>
              <div className="ml-auto flex gap-2">
                {selected.status === "aberta" && (
                  <button onClick={() => handleAdvance(selected.id)} className="px-3 py-1.5 rounded-md text-sm bg-amber-500/20 text-amber-400 border border-amber-500/30 hover:bg-amber-500/30 transition-colors">Iniciar Atendimento</button>
                )}
                {selected.status !== "finalizada" && (
                  <button onClick={() => handleFinalize(selected.id)} className="px-3 py-1.5 rounded-md text-sm bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/30 transition-colors">Finalizar OS</button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
