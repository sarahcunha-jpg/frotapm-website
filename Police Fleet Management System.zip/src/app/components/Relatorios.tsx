import { useState } from "react";
import { FileText, Download, BarChart2, Car, Wrench, AlertTriangle } from "lucide-react";
import { viaturas, ordensServico, historico, manutencaoItens } from "../data/mockData";

const RELATORIOS = [
  { id: "frota", label: "Situação da Frota", icon: Car, desc: "Status completo de todas as viaturas cadastradas" },
  { id: "manutencoes", label: "Manutenções Vencidas", icon: AlertTriangle, desc: "Itens com prazo de manutenção vencido ou próximo" },
  { id: "os", label: "Ordens de Serviço", icon: Wrench, desc: "Listagem de ordens de serviço por período" },
  { id: "custos", label: "Custos Mensais", icon: BarChart2, desc: "Custo consolidado de manutenção por mês" },
  { id: "historico", label: "Histórico por Viatura", icon: FileText, desc: "Registro completo de manutenções por viatura" },
  { id: "kpi", label: "Indicadores de Desempenho", icon: BarChart2, desc: "KPIs: disponibilidade, MTTR, MTBF e custo por viatura" },
];

export default function Relatorios() {
  const [selected, setSelected] = useState<string | null>(null);
  const [periodo, setPeriodo] = useState({ inicio: "2025-01-01", fim: "2025-06-30" });

  function renderPreview() {
    switch (selected) {
      case "frota":
        return (
          <table className="w-full text-xs">
            <thead><tr className="border-b border-border">{["Nº", "Placa", "Modelo", "Ano", "KM", "Unidade", "Status", "Próx. Revisão"].map(h => <th key={h} className="text-left text-muted-foreground px-3 py-2 font-medium">{h}</th>)}</tr></thead>
            <tbody>{viaturas.map((v, i) => (
              <tr key={v.id} className={`border-b border-border/40 ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                <td className="px-3 py-2 mono font-medium" style={{ fontFamily: "DM Mono, monospace" }}>{v.numero}</td>
                <td className="px-3 py-2 mono" style={{ fontFamily: "DM Mono, monospace" }}>{v.placa}</td>
                <td className="px-3 py-2">{v.modelo}</td>
                <td className="px-3 py-2 text-muted-foreground">{v.ano}</td>
                <td className="px-3 py-2 mono text-muted-foreground" style={{ fontFamily: "DM Mono, monospace" }}>{v.km.toLocaleString("pt-BR")}</td>
                <td className="px-3 py-2 text-muted-foreground">{v.unidade}</td>
                <td className="px-3 py-2 capitalize" style={{ color: v.status === "operação" ? "#34d399" : v.status === "manutenção" ? "#fbbf24" : "#f87171" }}>{v.status}</td>
                <td className="px-3 py-2 mono text-muted-foreground" style={{ fontFamily: "DM Mono, monospace" }}>{v.proximaRevisao}</td>
              </tr>
            ))}</tbody>
          </table>
        );
      case "manutencoes":
        return (
          <table className="w-full text-xs">
            <thead><tr className="border-b border-border">{["Item", "Frequência", "Próxima Data", "Status"].map(h => <th key={h} className="text-left text-muted-foreground px-3 py-2 font-medium">{h}</th>)}</tr></thead>
            <tbody>{manutencaoItens.filter(m => m.status !== "ok").map((m, i) => (
              <tr key={m.id} className={`border-b border-border/40 ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                <td className="px-3 py-2 font-medium">{m.item}</td>
                <td className="px-3 py-2 text-muted-foreground">{m.frequencia}</td>
                <td className="px-3 py-2 mono" style={{ fontFamily: "DM Mono, monospace", color: m.status === "vencida" ? "#f87171" : "#fbbf24" }}>{m.proximaData}</td>
                <td className="px-3 py-2 capitalize" style={{ color: m.status === "vencida" ? "#f87171" : "#fbbf24" }}>{m.status}</td>
              </tr>
            ))}</tbody>
          </table>
        );
      case "os":
        return (
          <table className="w-full text-xs">
            <thead><tr className="border-b border-border">{["OS", "Data", "Viatura", "Problema", "Responsável", "Custo", "Status"].map(h => <th key={h} className="text-left text-muted-foreground px-3 py-2 font-medium">{h}</th>)}</tr></thead>
            <tbody>{ordensServico.map((o, i) => (
              <tr key={o.id} className={`border-b border-border/40 ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                <td className="px-3 py-2 mono" style={{ fontFamily: "DM Mono, monospace" }}>{o.numero}</td>
                <td className="px-3 py-2 mono text-muted-foreground" style={{ fontFamily: "DM Mono, monospace" }}>{o.data}</td>
                <td className="px-3 py-2 text-muted-foreground">{o.viatura.split("–")[0]}</td>
                <td className="px-3 py-2 max-w-[160px] truncate">{o.problema}</td>
                <td className="px-3 py-2 text-muted-foreground">{o.responsavel}</td>
                <td className="px-3 py-2 mono text-amber-400" style={{ fontFamily: "DM Mono, monospace" }}>R$ {o.custo.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</td>
                <td className="px-3 py-2 capitalize" style={{ color: o.status === "finalizada" ? "#34d399" : o.status === "andamento" ? "#fbbf24" : "#60a5fa" }}>{o.status}</td>
              </tr>
            ))}</tbody>
          </table>
        );
      case "historico":
        return (
          <table className="w-full text-xs">
            <thead><tr className="border-b border-border">{["Viatura", "Data", "Tipo", "Serviço", "KM", "Custo", "Responsável"].map(h => <th key={h} className="text-left text-muted-foreground px-3 py-2 font-medium">{h}</th>)}</tr></thead>
            <tbody>{historico.map((h, i) => {
              const v = viaturas.find(v => v.id === h.viaturaId);
              return (
                <tr key={h.id} className={`border-b border-border/40 ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                  <td className="px-3 py-2 mono font-medium" style={{ fontFamily: "DM Mono, monospace" }}>{v?.numero} – {v?.placa}</td>
                  <td className="px-3 py-2 mono text-muted-foreground" style={{ fontFamily: "DM Mono, monospace" }}>{h.data}</td>
                  <td className="px-3 py-2 capitalize" style={{ color: h.tipo === "preventiva" ? "#60a5fa" : "#fbbf24" }}>{h.tipo}</td>
                  <td className="px-3 py-2 max-w-[180px] truncate">{h.servico}</td>
                  <td className="px-3 py-2 mono text-muted-foreground" style={{ fontFamily: "DM Mono, monospace" }}>{h.km.toLocaleString("pt-BR")}</td>
                  <td className="px-3 py-2 mono text-amber-400" style={{ fontFamily: "DM Mono, monospace" }}>R$ {h.custo.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</td>
                  <td className="px-3 py-2 text-muted-foreground">{h.responsavel}</td>
                </tr>
              );
            })}</tbody>
          </table>
        );
      default:
        return <div className="text-center py-8 text-muted-foreground text-sm">Selecione um relatório para visualizar</div>;
    }
  }

  const totalCusto = ordensServico.reduce((a, o) => a + o.custo, 0);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "Roboto Slab, serif" }}>Relatórios</h1>
        <p className="text-muted-foreground text-xs mt-0.5">Geração e exportação de relatórios operacionais</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
        {RELATORIOS.map(r => (
          <button key={r.id} onClick={() => setSelected(r.id === selected ? null : r.id)} className={`flex items-start gap-3 p-4 rounded-lg border text-left transition-colors ${selected === r.id ? "border-primary/50 bg-primary/10" : "border-border bg-card hover:border-border/80"}`}>
            <r.icon size={16} className={selected === r.id ? "text-primary mt-0.5" : "text-muted-foreground mt-0.5"} />
            <div>
              <p className={`font-medium text-sm mb-0.5 ${selected === r.id ? "text-primary" : "text-foreground"}`}>{r.label}</p>
              <p className="text-muted-foreground text-xs">{r.desc}</p>
            </div>
          </button>
        ))}
      </div>

      {selected && (
        <>
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-2">
              <label className="text-xs text-muted-foreground">De:</label>
              <input type="date" value={periodo.inicio} onChange={e => setPeriodo(p => ({ ...p, inicio: e.target.value }))} className="bg-card border border-border rounded-md px-3 py-1.5 text-sm text-foreground outline-none focus:border-primary/50" />
            </div>
            <div className="flex items-center gap-2">
              <label className="text-xs text-muted-foreground">Até:</label>
              <input type="date" value={periodo.fim} onChange={e => setPeriodo(p => ({ ...p, fim: e.target.value }))} className="bg-card border border-border rounded-md px-3 py-1.5 text-sm text-foreground outline-none focus:border-primary/50" />
            </div>
            <div className="ml-auto flex gap-2">
              <button className="flex items-center gap-2 px-4 py-2 rounded-md text-sm border border-border text-muted-foreground hover:text-foreground hover:border-foreground/20 transition-colors">
                <Download size={13} /> Excel
              </button>
              <button className="flex items-center gap-2 px-4 py-2 rounded-md text-sm bg-primary text-primary-foreground hover:bg-primary/90 transition-colors font-medium">
                <Download size={13} /> PDF
              </button>
            </div>
          </div>

          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-border">
              <div>
                <h3 className="font-semibold text-foreground text-sm" style={{ fontFamily: "Roboto Slab, serif" }}>{RELATORIOS.find(r => r.id === selected)?.label}</h3>
                <p className="text-xs text-muted-foreground mt-0.5">Período: {periodo.inicio} a {periodo.fim} · 10º BPM Blumenau/SC</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-muted-foreground">Custo Total</p>
                <p className="mono font-bold text-amber-400 text-sm" style={{ fontFamily: "DM Mono, monospace" }}>R$ {totalCusto.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</p>
              </div>
            </div>
            <div className="overflow-x-auto p-2">
              {renderPreview()}
            </div>
            <div className="px-5 py-3 border-t border-border text-xs text-muted-foreground flex justify-between">
              <span>Sistema de Gestão de Frota — PMSC · 10º BPM Blumenau</span>
              <span>Gerado em {new Date().toLocaleDateString("pt-BR")}</span>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
