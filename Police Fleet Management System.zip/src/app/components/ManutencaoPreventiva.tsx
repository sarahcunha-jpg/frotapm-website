import { useState } from "react";
import { AlertTriangle, CheckCircle, XCircle, Plus, X } from "lucide-react";
import { ManutencaoItem, manutencaoItens as initialItens, viaturas } from "../data/mockData";

const STATUS_CONFIG = {
  ok: { icon: CheckCircle, color: "text-emerald-400", bg: "bg-emerald-500/10 border-emerald-500/20", label: "No prazo" },
  alerta: { icon: AlertTriangle, color: "text-amber-400", bg: "bg-amber-500/10 border-amber-500/20", label: "Próximo do vencimento" },
  vencida: { icon: XCircle, color: "text-red-400", bg: "bg-red-500/10 border-red-500/20", label: "Vencida" },
};

export default function ManutencaoPreventiva() {
  const [items, setItems] = useState<ManutencaoItem[]>(initialItens);
  const [selectedViatura, setSelectedViatura] = useState("v01");
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ item: "", frequencia: "", ultimaData: "", ultimoKm: "", proximaData: "", proximoKm: "" });

  const viatura = viaturas.find(v => v.id === selectedViatura);

  function handleAdd() {
    if (!form.item || !form.frequencia) return;
    const newItem: ManutencaoItem = {
      id: `m${Date.now()}`, item: form.item, frequencia: form.frequencia,
      ultimaData: form.ultimaData, ultimoKm: Number(form.ultimoKm),
      proximaData: form.proximaData, proximoKm: Number(form.proximoKm), status: "ok",
    };
    setItems(i => [...i, newItem]);
    setModal(false);
    setForm({ item: "", frequencia: "", ultimaData: "", ultimoKm: "", proximaData: "", proximoKm: "" });
  }

  const counts = { ok: items.filter(i => i.status === "ok").length, alerta: items.filter(i => i.status === "alerta").length, vencida: items.filter(i => i.status === "vencida").length };

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "Roboto Slab, serif" }}>Manutenção Preventiva</h1>
          <p className="text-muted-foreground text-xs mt-0.5">Plano de revisões e intervalos programados</p>
        </div>
        <button onClick={() => setModal(true)} className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-md text-sm font-medium hover:bg-primary/90 transition-colors">
          <Plus size={15} /> Novo Item
        </button>
      </div>

      <div className="flex gap-3 flex-wrap items-center">
        <div>
          <label className="text-xs text-muted-foreground mr-2">Viatura:</label>
          <select value={selectedViatura} onChange={e => setSelectedViatura(e.target.value)} className="bg-card border border-border rounded-md px-3 py-1.5 text-sm text-foreground outline-none focus:border-primary/50">
            {viaturas.map(v => <option key={v.id} value={v.id}>{v.numero} – {v.placa} {v.modelo}</option>)}
          </select>
        </div>
        <div className="flex gap-2 ml-auto">
          {Object.entries(STATUS_CONFIG).map(([key, cfg]) => (
            <div key={key} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md border text-xs ${cfg.bg} ${cfg.color}`}>
              <cfg.icon size={12} />
              <span>{cfg.label}</span>
              <span className="font-bold">{counts[key as keyof typeof counts]}</span>
            </div>
          ))}
        </div>
      </div>

      {viatura && (
        <div className="bg-card border border-border rounded-lg p-4 flex items-center gap-6">
          <div>
            <p className="text-xs text-muted-foreground">Viatura</p>
            <p className="font-semibold text-foreground">{viatura.numero} – {viatura.modelo}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Placa</p>
            <p className="font-semibold mono" style={{ fontFamily: "DM Mono, monospace" }}>{viatura.placa}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">KM Atual</p>
            <p className="font-semibold mono" style={{ fontFamily: "DM Mono, monospace" }}>{viatura.km.toLocaleString("pt-BR")}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Unidade</p>
            <p className="font-semibold text-foreground text-sm">{viatura.unidade}</p>
          </div>
          <div className="ml-auto">
            <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded text-xs border capitalize ${viatura.status === "operação" ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" : "bg-amber-500/10 border-amber-500/20 text-amber-400"}`}>
              {viatura.status}
            </span>
          </div>
        </div>
      )}

      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border">
              {["Item de Manutenção", "Frequência", "Última Data", "Último KM", "Próxima Data", "Próximo KM", "Status"].map(h => (
                <th key={h} className="text-left text-xs text-muted-foreground font-medium px-4 py-3 uppercase tracking-wider whitespace-nowrap">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {items.map((item, i) => {
              const cfg = STATUS_CONFIG[item.status];
              return (
                <tr key={item.id} className={`border-b border-border/50 hover:bg-muted/20 transition-colors ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                  <td className="px-4 py-3 text-foreground font-medium">{item.item}</td>
                  <td className="px-4 py-3 text-muted-foreground text-xs">{item.frequencia}</td>
                  <td className="px-4 py-3 mono text-muted-foreground text-xs" style={{ fontFamily: "DM Mono, monospace" }}>{item.ultimaData}</td>
                  <td className="px-4 py-3 mono text-muted-foreground text-xs" style={{ fontFamily: "DM Mono, monospace" }}>{item.ultimoKm ? `${item.ultimoKm.toLocaleString("pt-BR")} km` : "—"}</td>
                  <td className="px-4 py-3 mono text-xs" style={{ fontFamily: "DM Mono, monospace", color: item.status === "vencida" ? "#f87171" : item.status === "alerta" ? "#fbbf24" : "#94a3b8" }}>{item.proximaData}</td>
                  <td className="px-4 py-3 mono text-muted-foreground text-xs" style={{ fontFamily: "DM Mono, monospace" }}>{item.proximoKm ? `${item.proximoKm.toLocaleString("pt-BR")} km` : "—"}</td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs border ${cfg.bg} ${cfg.color}`}>
                      <cfg.icon size={10} /> {cfg.label}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {modal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-card border border-border rounded-xl w-full max-w-lg shadow-2xl">
            <div className="flex items-center justify-between px-6 py-4 border-b border-border">
              <h2 className="font-bold text-foreground" style={{ fontFamily: "Roboto Slab, serif" }}>Novo Item de Manutenção</h2>
              <button onClick={() => setModal(false)} className="text-muted-foreground hover:text-foreground transition-colors"><X size={18} /></button>
            </div>
            <div className="p-6 grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block">item</label>
                <input value={form.item} onChange={e => setForm(f => ({ ...f, item: e.target.value }))} className="w-full bg-input-background border border-border rounded-md px-3 py-2 text-sm text-foreground outline-none focus:border-primary/50 transition-colors" placeholder="Ex: Troca de óleo e filtro" />
              </div>
              <div className="col-span-2">
                <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block">frequência</label>
                <input value={form.frequencia} onChange={e => setForm(f => ({ ...f, frequencia: e.target.value }))} className="w-full bg-input-background border border-border rounded-md px-3 py-2 text-sm text-foreground outline-none focus:border-primary/50 transition-colors" placeholder="Ex: A cada 10.000 km" />
              </div>
              {[["Última Data", "ultimaData", "date"], ["Último KM", "ultimoKm", "number"], ["Próxima Data", "proximaData", "date"], ["Próximo KM", "proximoKm", "number"]].map(([label, key, type]) => (
                <div key={key}>
                  <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block">{label}</label>
                  <input type={type} value={(form as any)[key]} onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))} className="w-full bg-input-background border border-border rounded-md px-3 py-2 text-sm text-foreground outline-none focus:border-primary/50 transition-colors" />
                </div>
              ))}
            </div>
            <div className="flex justify-end gap-3 px-6 py-4 border-t border-border">
              <button onClick={() => setModal(false)} className="px-4 py-2 rounded-md text-sm text-muted-foreground border border-border hover:border-foreground/20 transition-colors">Cancelar</button>
              <button onClick={handleAdd} className="px-4 py-2 rounded-md text-sm bg-primary text-primary-foreground hover:bg-primary/90 font-medium transition-colors">Adicionar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
