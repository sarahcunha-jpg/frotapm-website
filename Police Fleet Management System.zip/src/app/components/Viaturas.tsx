import { useState } from "react";
import { Plus, Search, Edit2, Trash2, X } from "lucide-react";
import { Viatura, ViaturaStatus, viaturas as initialViaturas } from "../data/mockData";

const STATUS_COLORS: Record<ViaturaStatus, string> = {
  "operação": "bg-emerald-500/15 text-emerald-400 border-emerald-500/25",
  "manutenção": "bg-amber-500/15 text-amber-400 border-amber-500/25",
  "indisponível": "bg-red-500/15 text-red-400 border-red-500/25",
};

const UNIDADES = ["10º BPM – Centro", "1ª CIPM – Garcia", "2ª CIPM – Velha", "3ª CIPM – Itoupava", "4ª CIPM – Ponta Aguda", "5ª CIPM – Fortaleza", "Comando BPTUR"];

interface FormData {
  numero: string; placa: string; modelo: string; ano: string;
  km: string; unidade: string; status: ViaturaStatus;
  ultimaRevisao: string; proximaRevisao: string;
}

const emptyForm: FormData = {
  numero: "", placa: "", modelo: "", ano: "2023",
  km: "0", unidade: UNIDADES[0], status: "operação",
  ultimaRevisao: "", proximaRevisao: "",
};

export default function Viaturas() {
  const [data, setData] = useState<Viatura[]>(initialViaturas);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState<ViaturaStatus | "todos">("todos");
  const [modal, setModal] = useState<"add" | "edit" | null>(null);
  const [editing, setEditing] = useState<Viatura | null>(null);
  const [form, setForm] = useState<FormData>(emptyForm);

  const filtered = data.filter(v => {
    const matchSearch = v.numero.includes(search) || v.placa.toLowerCase().includes(search.toLowerCase()) || v.modelo.toLowerCase().includes(search.toLowerCase()) || v.unidade.toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === "todos" || v.status === filterStatus;
    return matchSearch && matchStatus;
  });

  function openAdd() { setForm(emptyForm); setEditing(null); setModal("add"); }
  function openEdit(v: Viatura) {
    setForm({ numero: v.numero, placa: v.placa, modelo: v.modelo, ano: String(v.ano), km: String(v.km), unidade: v.unidade, status: v.status, ultimaRevisao: v.ultimaRevisao, proximaRevisao: v.proximaRevisao });
    setEditing(v); setModal("edit");
  }
  function handleDelete(id: string) { setData(d => d.filter(v => v.id !== id)); }
  function handleSubmit() {
    if (!form.numero || !form.placa || !form.modelo) return;
    if (modal === "add") {
      const newV: Viatura = { id: `v${Date.now()}`, numero: form.numero, placa: form.placa, modelo: form.modelo, ano: Number(form.ano), km: Number(form.km), unidade: form.unidade, status: form.status, ultimaRevisao: form.ultimaRevisao, proximaRevisao: form.proximaRevisao, x: 0, y: 0, velocidade: 0, direcao: 0 };
      setData(d => [...d, newV]);
    } else if (editing) {
      setData(d => d.map(v => v.id === editing.id ? { ...v, ...form, ano: Number(form.ano), km: Number(form.km) } : v));
    }
    setModal(null);
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "Roboto Slab, serif" }}>Cadastro de Viaturas</h1>
          <p className="text-muted-foreground text-xs mt-0.5">{data.length} viaturas cadastradas</p>
        </div>
        <button onClick={openAdd} className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-md text-sm font-medium hover:bg-primary/90 transition-colors">
          <Plus size={15} /> Nova Viatura
        </button>
      </div>

      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar por número, placa ou modelo..." className="w-full bg-card border border-border rounded-md pl-9 pr-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/50 transition-colors" />
        </div>
        {(["todos", "operação", "manutenção", "indisponível"] as const).map(s => (
          <button key={s} onClick={() => setFilterStatus(s)} className={`px-3 py-2 rounded-md text-xs font-medium border transition-colors capitalize ${filterStatus === s ? "bg-primary/20 border-primary/40 text-primary" : "bg-card border-border text-muted-foreground hover:text-foreground"}`}>
            {s === "todos" ? "Todos" : s}
          </button>
        ))}
      </div>

      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                {["Nº", "Placa", "Modelo", "Ano", "KM", "Unidade", "Status", "Próx. Revisão", ""].map(h => (
                  <th key={h} className="text-left text-xs text-muted-foreground font-medium px-4 py-3 uppercase tracking-wider whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((v, i) => (
                <tr key={v.id} className={`border-b border-border/50 hover:bg-muted/30 transition-colors ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                  <td className="px-4 py-3 font-medium text-foreground mono" style={{ fontFamily: "DM Mono, monospace" }}>{v.numero}</td>
                  <td className="px-4 py-3 mono text-foreground" style={{ fontFamily: "DM Mono, monospace" }}>{v.placa}</td>
                  <td className="px-4 py-3 text-foreground">{v.modelo}</td>
                  <td className="px-4 py-3 text-muted-foreground">{v.ano}</td>
                  <td className="px-4 py-3 mono text-muted-foreground" style={{ fontFamily: "DM Mono, monospace" }}>{v.km.toLocaleString("pt-BR")} km</td>
                  <td className="px-4 py-3 text-muted-foreground text-xs">{v.unidade}</td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex px-2 py-0.5 rounded text-xs border capitalize ${STATUS_COLORS[v.status]}`}>{v.status}</span>
                  </td>
                  <td className="px-4 py-3 mono text-muted-foreground text-xs" style={{ fontFamily: "DM Mono, monospace" }}>{v.proximaRevisao}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button onClick={() => openEdit(v)} className="p-1.5 rounded hover:bg-primary/15 text-muted-foreground hover:text-primary transition-colors"><Edit2 size={13} /></button>
                      <button onClick={() => handleDelete(v.id)} className="p-1.5 rounded hover:bg-red-500/15 text-muted-foreground hover:text-red-400 transition-colors"><Trash2 size={13} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && <div className="text-center py-12 text-muted-foreground text-sm">Nenhuma viatura encontrada.</div>}
      </div>

      {modal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-card border border-border rounded-xl w-full max-w-xl shadow-2xl">
            <div className="flex items-center justify-between px-6 py-4 border-b border-border">
              <h2 className="font-bold text-foreground" style={{ fontFamily: "Roboto Slab, serif" }}>{modal === "add" ? "Nova Viatura" : "Editar Viatura"}</h2>
              <button onClick={() => setModal(null)} className="text-muted-foreground hover:text-foreground transition-colors"><X size={18} /></button>
            </div>
            <div className="p-6 grid grid-cols-2 gap-4">
              {([["número", "numero", "text"], ["placa", "placa", "text"], ["modelo", "modelo", "text"], ["ano", "ano", "number"], ["quilometragem", "km", "number"]] as const).map(([label, key, type]) => (
                <div key={key}>
                  <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block">{label}</label>
                  <input type={type} value={(form as any)[key]} onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))} className="w-full bg-input-background border border-border rounded-md px-3 py-2 text-sm text-foreground outline-none focus:border-primary/50 transition-colors" />
                </div>
              ))}
              <div>
                <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block">status</label>
                <select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value as ViaturaStatus }))} className="w-full bg-input-background border border-border rounded-md px-3 py-2 text-sm text-foreground outline-none focus:border-primary/50 transition-colors">
                  {["operação", "manutenção", "indisponível"].map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div className="col-span-2">
                <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block">unidade responsável</label>
                <select value={form.unidade} onChange={e => setForm(f => ({ ...f, unidade: e.target.value }))} className="w-full bg-input-background border border-border rounded-md px-3 py-2 text-sm text-foreground outline-none focus:border-primary/50 transition-colors">
                  {UNIDADES.map(u => <option key={u} value={u}>{u}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block">última revisão</label>
                <input type="date" value={form.ultimaRevisao} onChange={e => setForm(f => ({ ...f, ultimaRevisao: e.target.value }))} className="w-full bg-input-background border border-border rounded-md px-3 py-2 text-sm text-foreground outline-none focus:border-primary/50 transition-colors" />
              </div>
              <div>
                <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block">próxima revisão</label>
                <input type="date" value={form.proximaRevisao} onChange={e => setForm(f => ({ ...f, proximaRevisao: e.target.value }))} className="w-full bg-input-background border border-border rounded-md px-3 py-2 text-sm text-foreground outline-none focus:border-primary/50 transition-colors" />
              </div>
            </div>
            <div className="flex justify-end gap-3 px-6 py-4 border-t border-border">
              <button onClick={() => setModal(null)} className="px-4 py-2 rounded-md text-sm text-muted-foreground hover:text-foreground border border-border hover:border-foreground/20 transition-colors">Cancelar</button>
              <button onClick={handleSubmit} className="px-4 py-2 rounded-md text-sm bg-primary text-primary-foreground hover:bg-primary/90 font-medium transition-colors">Salvar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
