import { useState } from "react";
import { Plus, X, Shield, Wrench, User, Star } from "lucide-react";
import { Usuario, UserRole, usuarios as initialUsuarios } from "../data/mockData";

const ROLE_CONFIG: Record<UserRole, { label: string; color: string; bg: string; icon: typeof Shield }> = {
  administrador: { label: "Administrador", color: "text-violet-400", bg: "bg-violet-500/10 border-violet-500/20", icon: Star },
  gestor: { label: "Gestor", color: "text-primary", bg: "bg-primary/10 border-primary/20", icon: Shield },
  mecanico: { label: "Mecânico", color: "text-amber-400", bg: "bg-amber-500/10 border-amber-500/20", icon: Wrench },
  policial: { label: "Policial", color: "text-emerald-400", bg: "bg-emerald-500/10 border-emerald-500/20", icon: User },
};

const UNIDADES = ["Comando 10º BPM", "10º BPM – Centro", "1ª CIPM – Garcia", "2ª CIPM – Velha", "3ª CIPM – Itoupava", "4ª CIPM – Ponta Aguda", "5ª CIPM – Fortaleza", "Comando BPTUR", "Oficina Central"];

export default function Usuarios() {
  const [users, setUsers] = useState<Usuario[]>(initialUsuarios);
  const [filterRole, setFilterRole] = useState<UserRole | "todos">("todos");
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ nome: "", matricula: "", email: "", role: "policial" as UserRole, unidade: UNIDADES[0] });

  const filtered = filterRole === "todos" ? users : users.filter(u => u.role === filterRole);

  function handleAdd() {
    if (!form.nome || !form.matricula) return;
    setUsers(u => [...u, { id: `u${Date.now()}`, ...form, ativo: true }]);
    setModal(false);
    setForm({ nome: "", matricula: "", email: "", role: "policial", unidade: UNIDADES[0] });
  }
  function toggleAtivo(id: string) { setUsers(u => u.map(usr => usr.id === id ? { ...usr, ativo: !usr.ativo } : usr)); }

  const counts = Object.fromEntries((["administrador", "gestor", "mecanico", "policial"] as UserRole[]).map(r => [r, users.filter(u => u.role === r).length]));

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "Roboto Slab, serif" }}>Controle de Acesso</h1>
          <p className="text-muted-foreground text-xs mt-0.5">{users.length} usuários cadastrados · {users.filter(u => u.ativo).length} ativos</p>
        </div>
        <button onClick={() => setModal(true)} className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-md text-sm font-medium hover:bg-primary/90 transition-colors">
          <Plus size={15} /> Novo Usuário
        </button>
      </div>

      <div className="grid grid-cols-4 gap-3">
        {(["administrador", "gestor", "mecanico", "policial"] as UserRole[]).map(role => {
          const cfg = ROLE_CONFIG[role];
          return (
            <button key={role} onClick={() => setFilterRole(f => f === role ? "todos" : role)} className={`flex items-center gap-3 p-3 rounded-lg border transition-colors text-left ${filterRole === role ? `${cfg.bg} border-opacity-100` : "border-border bg-card hover:border-border/80"}`}>
              <cfg.icon size={14} className={cfg.color} />
              <div>
                <p className="text-muted-foreground text-xs">{cfg.label}</p>
                <p className="font-bold mono text-xl" style={{ fontFamily: "DM Mono, monospace", color: filterRole === role ? (cfg.color.replace("text-", "")) : "#e2e8f0" }}>{counts[role]}</p>
              </div>
            </button>
          );
        })}
      </div>

      <div className="space-y-2">
        {filtered.map(u => {
          const cfg = ROLE_CONFIG[u.role];
          return (
            <div key={u.id} className={`bg-card border border-border rounded-lg p-4 flex items-center gap-4 hover:border-border/80 transition-colors ${!u.ativo ? "opacity-50" : ""}`}>
              <div className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 ${cfg.bg} border`}>
                <cfg.icon size={15} className={cfg.color} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-foreground text-sm truncate">{u.nome}</span>
                  <span className={`inline-flex px-2 py-0.5 rounded text-xs border ${cfg.bg} ${cfg.color} flex-shrink-0`}>{cfg.label}</span>
                  {!u.ativo && <span className="text-xs text-red-400 flex-shrink-0">Inativo</span>}
                </div>
                <div className="flex items-center gap-3 mt-0.5 flex-wrap">
                  <span className="mono text-xs text-muted-foreground" style={{ fontFamily: "DM Mono, monospace" }}>{u.matricula}</span>
                  <span className="text-xs text-muted-foreground truncate">{u.email}</span>
                  <span className="text-xs text-muted-foreground">{u.unidade}</span>
                </div>
              </div>
              <button onClick={() => toggleAtivo(u.id)} className={`px-3 py-1 rounded-md text-xs border transition-colors flex-shrink-0 ${u.ativo ? "border-red-500/30 text-red-400 hover:bg-red-500/10" : "border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/10"}`}>
                {u.ativo ? "Desativar" : "Ativar"}
              </button>
            </div>
          );
        })}
      </div>

      <div className="bg-card border border-border rounded-xl p-5">
        <h3 className="font-semibold text-foreground text-sm mb-4" style={{ fontFamily: "Roboto Slab, serif" }}>Permissões por Perfil</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead><tr className="border-b border-border">{["Funcionalidade", "Administrador", "Gestor", "Mecânico", "Policial"].map(h => <th key={h} className="text-left text-muted-foreground px-3 py-2 font-medium">{h}</th>)}</tr></thead>
            <tbody>
              {[
                ["Cadastro de Viaturas", true, false, false, false],
                ["Aprovação de Manutenções", true, true, false, false],
                ["Ordens de Serviço", true, true, true, false],
                ["Atualizar OS", true, true, true, false],
                ["Visualizar Rastreamento", true, true, false, false],
                ["Emitir Relatórios", true, true, false, false],
                ["Consultar Viatura", true, true, true, true],
                ["Solicitar Manutenção", true, true, true, true],
                ["Gestão de Usuários", true, false, false, false],
              ].map(([label, ...perms]) => (
                <tr key={label as string} className="border-b border-border/40 hover:bg-muted/20">
                  <td className="px-3 py-2.5 text-foreground">{label as string}</td>
                  {perms.map((perm, i) => (
                    <td key={i} className="px-3 py-2.5 text-center">
                      {perm ? <span className="text-emerald-400">✓</span> : <span className="text-muted-foreground/40">—</span>}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {modal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-card border border-border rounded-xl w-full max-w-md shadow-2xl">
            <div className="flex items-center justify-between px-6 py-4 border-b border-border">
              <h2 className="font-bold text-foreground" style={{ fontFamily: "Roboto Slab, serif" }}>Novo Usuário</h2>
              <button onClick={() => setModal(false)} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
            </div>
            <div className="p-6 space-y-4">
              {[["nome completo", "nome", "text"], ["matrícula", "matricula", "text"], ["e-mail", "email", "email"]].map(([label, key, type]) => (
                <div key={key}>
                  <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block">{label}</label>
                  <input type={type} value={(form as any)[key]} onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))} className="w-full bg-input-background border border-border rounded-md px-3 py-2 text-sm text-foreground outline-none focus:border-primary/50 transition-colors" />
                </div>
              ))}
              <div>
                <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block">perfil de acesso</label>
                <select value={form.role} onChange={e => setForm(f => ({ ...f, role: e.target.value as UserRole }))} className="w-full bg-input-background border border-border rounded-md px-3 py-2 text-sm text-foreground outline-none focus:border-primary/50">
                  {(["administrador", "gestor", "mecanico", "policial"] as UserRole[]).map(r => <option key={r} value={r}>{ROLE_CONFIG[r].label}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block">unidade</label>
                <select value={form.unidade} onChange={e => setForm(f => ({ ...f, unidade: e.target.value }))} className="w-full bg-input-background border border-border rounded-md px-3 py-2 text-sm text-foreground outline-none focus:border-primary/50">
                  {UNIDADES.map(u => <option key={u} value={u}>{u}</option>)}
                </select>
              </div>
            </div>
            <div className="flex justify-end gap-3 px-6 py-4 border-t border-border">
              <button onClick={() => setModal(false)} className="px-4 py-2 rounded-md text-sm text-muted-foreground border border-border hover:border-foreground/20 transition-colors">Cancelar</button>
              <button onClick={handleAdd} className="px-4 py-2 rounded-md text-sm bg-primary text-primary-foreground hover:bg-primary/90 font-medium transition-colors">Cadastrar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
