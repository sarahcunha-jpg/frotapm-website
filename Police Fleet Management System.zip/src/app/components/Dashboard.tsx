import { AlertTriangle, Car, CheckCircle, Clock, TrendingUp, Wrench } from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, CartesianGrid, Cell,
  Legend, PieChart, Pie, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { disponibilidadeMensal, manutencoesMensais, viaturas, ordensServico, manutencaoItens } from "../data/mockData";

const COLORS = ["#1d6cf0", "#10b981", "#ef4444"];

function StatCard({ label, value, sub, icon: Icon, color }: {
  label: string; value: string | number; sub: string;
  icon: React.ComponentType<{ size?: number; className?: string }>; color: string;
}) {
  return (
    <div className="bg-card rounded-lg border border-border p-5 flex items-start gap-4">
      <div className={`p-2.5 rounded-md ${color}`}>
        <Icon size={18} className="text-white" />
      </div>
      <div>
        <p className="text-muted-foreground text-xs uppercase tracking-widest mb-1">{label}</p>
        <p className="text-3xl font-bold text-foreground mono" style={{ fontFamily: "DM Mono, monospace" }}>{value}</p>
        <p className="text-muted-foreground text-xs mt-1">{sub}</p>
      </div>
    </div>
  );
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-popover border border-border rounded-md px-3 py-2 text-xs shadow-lg">
        <p className="text-muted-foreground mb-1">{label}</p>
        {payload.map((p: any) => (
          <p key={p.name} style={{ color: p.color }}>{p.name}: <span className="text-foreground font-medium">{p.value}</span></p>
        ))}
      </div>
    );
  }
  return null;
};

export default function Dashboard() {
  const total = viaturas.length;
  const emOperacao = viaturas.filter(v => v.status === "operação").length;
  const emManutencao = viaturas.filter(v => v.status === "manutenção").length;
  const indisponiveis = viaturas.filter(v => v.status === "indisponível").length;
  const proximasRevisoes = viaturas.filter(v => {
    const diff = (new Date(v.proximaRevisao).getTime() - Date.now()) / (1000 * 60 * 60 * 24);
    return diff <= 30 && diff > 0;
  }).length;
  const osAbertas = ordensServico.filter(o => o.status !== "finalizada").length;
  const vencidas = manutencaoItens.filter(m => m.status === "vencida");
  const alertas = manutencaoItens.filter(m => m.status === "alerta");

  const pieData = [
    { name: "Em Operação", value: emOperacao },
    { name: "Em Manutenção", value: emManutencao },
    { name: "Indisponível", value: indisponiveis },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "Roboto Slab, serif" }}>Dashboard</h1>
        <p className="text-muted-foreground text-xs mt-0.5">Visão geral da frota — 10º BPM Blumenau</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total de Viaturas" value={total} sub="unidades cadastradas" icon={Car} color="bg-primary" />
        <StatCard label="Em Operação" value={emOperacao} sub={`${Math.round((emOperacao / total) * 100)}% da frota ativa`} icon={CheckCircle} color="bg-emerald-600" />
        <StatCard label="Em Manutenção" value={emManutencao + indisponiveis} sub={`${osAbertas} ordens abertas`} icon={Wrench} color="bg-amber-500" />
        <StatCard label="Próx. Revisões" value={proximasRevisoes} sub="nos próximos 30 dias" icon={Clock} color="bg-violet-600" />
      </div>

      {(vencidas.length > 0 || alertas.length > 0) && (
        <div className="bg-amber-500/10 border border-amber-500/25 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle size={15} className="text-amber-400" />
            <span className="text-amber-400 font-medium text-sm">Alertas de Manutenção</span>
          </div>
          <div className="space-y-1.5">
            {vencidas.map(m => (
              <div key={m.id} className="flex items-center gap-2 text-xs">
                <span className="w-2 h-2 rounded-full bg-red-500 flex-shrink-0" />
                <span className="text-foreground">{m.item}</span>
                <span className="text-red-400 ml-auto">Vencida em {m.proximaData}</span>
              </div>
            ))}
            {alertas.map(m => (
              <div key={m.id} className="flex items-center gap-2 text-xs">
                <span className="w-2 h-2 rounded-full bg-amber-400 flex-shrink-0" />
                <span className="text-foreground">{m.item}</span>
                <span className="text-amber-400 ml-auto">Vence em {m.proximaData}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-card border border-border rounded-lg p-5">
          <div className="flex items-center justify-between mb-5">
            <h3 className="text-sm font-semibold text-foreground" style={{ fontFamily: "Roboto Slab, serif" }}>Manutenções por Mês</h3>
            <span className="text-xs text-muted-foreground">Jan – Jun 2025</span>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={manutencoesMensais} barGap={4}>
              <CartesianGrid strokeDasharray="2 4" stroke="rgba(148,163,184,0.06)" />
              <XAxis dataKey="mes" tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: 11, color: "#64748b" }} />
              <Bar dataKey="preventiva" name="Preventiva" fill="#1d6cf0" radius={[3, 3, 0, 0]} />
              <Bar dataKey="corretiva" name="Corretiva" fill="#f59e0b" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-card border border-border rounded-lg p-5">
          <h3 className="text-sm font-semibold text-foreground mb-5" style={{ fontFamily: "Roboto Slab, serif" }}>Status da Frota</h3>
          <ResponsiveContainer width="100%" height={160}>
            <PieChart>
              <Pie data={pieData} cx="50%" cy="50%" innerRadius={45} outerRadius={70} paddingAngle={3} dataKey="value">
                {pieData.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-2">
            {pieData.map((d, i) => (
              <div key={d.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full" style={{ background: COLORS[i] }} />
                  <span className="text-muted-foreground">{d.name}</span>
                </div>
                <span className="text-foreground font-medium mono" style={{ fontFamily: "DM Mono, monospace" }}>{d.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-card border border-border rounded-lg p-5">
        <div className="flex items-center gap-2 mb-5">
          <TrendingUp size={14} className="text-primary" />
          <h3 className="text-sm font-semibold text-foreground" style={{ fontFamily: "Roboto Slab, serif" }}>Disponibilidade da Frota (%)</h3>
        </div>
        <ResponsiveContainer width="100%" height={140}>
          <AreaChart data={disponibilidadeMensal}>
            <defs>
              <linearGradient id="dispGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#1d6cf0" stopOpacity={0.2} />
                <stop offset="95%" stopColor="#1d6cf0" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="2 4" stroke="rgba(148,163,184,0.06)" />
            <XAxis dataKey="mes" tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis domain={[70, 100]} tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} />
            <Tooltip content={<CustomTooltip />} />
            <Area type="monotone" dataKey="disponibilidade" name="Disponibilidade %" stroke="#1d6cf0" fill="url(#dispGrad)" strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
