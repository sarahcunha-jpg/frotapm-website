import { useState, useEffect, useRef } from "react";
import { viaturas as initialViaturas, Viatura } from "../data/mockData";
import { Navigation, Wifi, WifiOff } from "lucide-react";

function lerp(a: number, b: number, t: number) { return a + (b - a) * t; }

export default function Rastreamento() {
  const [selected, setSelected] = useState<string | null>(null);
  const [positions, setPositions] = useState<Record<string, { x: number; y: number; heading: number }>>(() =>
    Object.fromEntries(initialViaturas.filter(v => v.status === "operação").map(v => [v.id, { x: v.x, y: v.y, heading: v.direcao }]))
  );
  const [targets] = useState<Record<string, { x: number; y: number }>>(() =>
    Object.fromEntries(initialViaturas.filter(v => v.status === "operação").map(v => [v.id, { x: v.x, y: v.y }]))
  );
  const targetsRef = useRef<Record<string, { x: number; y: number }>>(targets);
  const [lastUpdate, setLastUpdate] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      targetsRef.current = Object.fromEntries(
        Object.keys(targetsRef.current).map(id => {
          const cur = targetsRef.current[id];
          const nx = Math.max(5, Math.min(92, cur.x + (Math.random() - 0.5) * 6));
          const ny = Math.max(5, Math.min(88, cur.y + (Math.random() - 0.5) * 5));
          return [id, { x: nx, y: ny }];
        })
      );
      setPositions(prev => Object.fromEntries(
        Object.keys(prev).map(id => {
          const cur = prev[id];
          const tgt = targetsRef.current[id];
          const nx = lerp(cur.x, tgt.x, 0.12);
          const ny = lerp(cur.y, tgt.y, 0.12);
          const dx = tgt.x - cur.x; const dy = tgt.y - cur.y;
          const heading = Math.abs(dx) + Math.abs(dy) > 0.1 ? (Math.atan2(dy, dx) * 180 / Math.PI + 90 + 360) % 360 : cur.heading;
          return [id, { x: nx, y: ny, heading }];
        })
      ));
      setLastUpdate(new Date());
    }, 800);
    return () => clearInterval(interval);
  }, []);

  const activeViaturas = initialViaturas.filter(v => v.status === "operação");
  const selectedViatura = initialViaturas.find(v => v.id === selected);
  const pos = selected ? positions[selected] : null;

  return (
    <div className="space-y-5 h-full">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "Roboto Slab, serif" }}>Rastreamento em Tempo Real</h1>
          <p className="text-muted-foreground text-xs mt-0.5 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse inline-block" />
            Ao vivo — Atualizado às {lastUpdate.toLocaleTimeString("pt-BR")}
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded-full">
          <Wifi size={12} /> GPS Ativo — {activeViaturas.length} viaturas
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4" style={{ minHeight: 480 }}>
        <div className="lg:col-span-3 bg-card border border-border rounded-xl overflow-hidden relative" style={{ minHeight: 440 }}>
          <svg viewBox="0 0 100 100" className="w-full h-full" style={{ minHeight: 440, background: "#0d1a2e" }}>
            {/* Grid / city background */}
            <defs>
              <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
                <path d="M 10 0 L 0 0 0 10" fill="none" stroke="rgba(255,255,255,0.03)" strokeWidth="0.3" />
              </pattern>
            </defs>
            <rect width="100" height="100" fill="url(#grid)" />

            {/* Rio Itajaí-Açu – stylized river */}
            <path d="M 0 62 Q 15 58 28 64 Q 40 70 55 65 Q 70 60 85 67 Q 95 70 100 68" fill="none" stroke="#1a3a5c" strokeWidth="5" strokeLinecap="round" />
            <path d="M 0 62 Q 15 58 28 64 Q 40 70 55 65 Q 70 60 85 67 Q 95 70 100 68" fill="none" stroke="#1d4a7a" strokeWidth="3.5" strokeLinecap="round" />
            <text x="38" y="69" fill="#2a6fa8" fontSize="2" fontFamily="DM Mono, monospace">Rio Itajaí-Açu</text>

            {/* Major roads */}
            {[
              ["M 0 35 L 100 35", 1.5, "#1e2d3d"],
              ["M 0 50 L 100 50", 1.5, "#1e2d3d"],
              ["M 25 0 L 25 60", 1.5, "#1e2d3d"],
              ["M 50 0 L 50 60", 1.5, "#1e2d3d"],
              ["M 75 0 L 75 60", 1.5, "#1e2d3d"],
              ["M 0 20 L 100 20", 0.6, "#162230"],
              ["M 12 0 L 12 60", 0.6, "#162230"],
              ["M 38 0 L 38 60", 0.6, "#162230"],
              ["M 62 0 L 62 60", 0.6, "#162230"],
              ["M 88 0 L 88 60", 0.6, "#162230"],
            ].map(([d, w, c], i) => <path key={i} d={d as string} fill="none" stroke={c as string} strokeWidth={w as number} />)}

            {/* City blocks */}
            {[[14, 22, 8, 11], [26, 22, 10, 11], [40, 22, 8, 11], [52, 22, 10, 11], [66, 22, 8, 11], [14, 37, 8, 11], [26, 37, 10, 11], [52, 37, 10, 11], [66, 37, 8, 11]].map(([x, y, w, h], i) => (
              <rect key={i} x={x} y={y} width={w} height={h} fill="rgba(255,255,255,0.02)" rx="0.5" />
            ))}

            {/* Neighborhood labels */}
            {[["Centro", 42, 42], ["Garcia", 16, 30], ["Velha", 54, 42], ["Itoupava", 68, 30], ["Ponta Aguda", 28, 55]].map(([t, x, y]) => (
              <text key={t as string} x={x as number} y={y as number} fill="rgba(148,163,184,0.25)" fontSize="2.2" fontFamily="DM Mono, monospace" textAnchor="middle">{t as string}</text>
            ))}

            {/* HQ marker */}
            <circle cx={50} cy={35} r={2} fill="#1d6cf0" opacity={0.6} />
            <text x={50} y={32} fill="#1d6cf0" fontSize="1.8" fontFamily="DM Mono" textAnchor="middle" opacity={0.8}>10º BPM</text>

            {/* Vehicle markers */}
            {activeViaturas.map(v => {
              const p = positions[v.id];
              if (!p) return null;
              const isSel = v.id === selected;
              return (
                <g key={v.id} onClick={() => setSelected(v.id === selected ? null : v.id)} style={{ cursor: "pointer" }} transform={`translate(${p.x}, ${p.y})`}>
                  {isSel && <circle r={4.5} fill="none" stroke="#1d6cf0" strokeWidth={0.5} opacity={0.5} className="animate-ping" style={{ transformOrigin: "center", animation: "ping 1.5s cubic-bezier(0,0,0.2,1) infinite" }} />}
                  <circle r={2.2} fill={isSel ? "#1d6cf0" : "#10b981"} stroke={isSel ? "#60a5fa" : "#34d399"} strokeWidth={0.4} />
                  <g transform={`rotate(${p.heading})`}>
                    <path d="M 0 -1.5 L 0.6 0.8 L 0 0.3 L -0.6 0.8 Z" fill="white" opacity={0.9} />
                  </g>
                  <text x={0} y={-3.2} fill={isSel ? "#93c5fd" : "rgba(255,255,255,0.6)"} fontSize="1.8" fontFamily="DM Mono" textAnchor="middle">{v.numero}</text>
                </g>
              );
            })}

            {/* Inactive vehicles */}
            {initialViaturas.filter(v => v.status !== "operação").map(v => (
              <g key={v.id}>
                <circle cx={52} cy={37} r={1} fill="#ef4444" opacity={0.4} />
              </g>
            ))}
          </svg>

          <div className="absolute bottom-3 left-3 flex gap-3 text-xs">
            <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-emerald-400" />Em operação</div>
            <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-primary" />Selecionada</div>
            <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-red-400" />Indisponível</div>
          </div>
        </div>

        <div className="space-y-2 overflow-y-auto max-h-[480px]">
          <p className="text-xs text-muted-foreground uppercase tracking-wider px-1">Viaturas Ativas</p>
          {activeViaturas.map(v => {
            const p = positions[v.id];
            const isSel = v.id === selected;
            return (
              <button key={v.id} onClick={() => setSelected(v.id === selected ? null : v.id)} className={`w-full text-left p-3 rounded-lg border transition-colors ${isSel ? "border-primary/50 bg-primary/10" : "border-border bg-card hover:border-border/80"}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className="mono font-bold text-sm" style={{ fontFamily: "DM Mono, monospace", color: isSel ? "#60a5fa" : "#e2e8f0" }}>V-{v.numero}</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                </div>
                <p className="text-xs text-muted-foreground">{v.modelo}</p>
                <p className="text-xs text-muted-foreground">{v.placa}</p>
                {p && <p className="mono text-xs mt-1" style={{ fontFamily: "DM Mono, monospace", color: "#64748b" }}>x:{p.x.toFixed(1)} y:{p.y.toFixed(1)}</p>}
                <p className="mono text-xs" style={{ fontFamily: "DM Mono, monospace", color: "#f59e0b" }}>{v.velocidade} km/h</p>
              </button>
            );
          })}

          <p className="text-xs text-muted-foreground uppercase tracking-wider px-1 pt-2">Fora de Serviço</p>
          {initialViaturas.filter(v => v.status !== "operação").map(v => (
            <div key={v.id} className="p-3 rounded-lg border border-border bg-card opacity-50">
              <div className="flex items-center justify-between mb-1">
                <span className="mono font-bold text-sm" style={{ fontFamily: "DM Mono, monospace" }}>V-{v.numero}</span>
                <WifiOff size={11} className="text-muted-foreground" />
              </div>
              <p className="text-xs text-muted-foreground">{v.modelo}</p>
              <span className={`text-xs capitalize ${v.status === "manutenção" ? "text-amber-400" : "text-red-400"}`}>{v.status}</span>
            </div>
          ))}
        </div>
      </div>

      {selectedViatura && pos && (
        <div className="bg-card border border-primary/30 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-3">
            <Navigation size={14} className="text-primary" />
            <h3 className="font-semibold text-foreground text-sm" style={{ fontFamily: "Roboto Slab, serif" }}>Viatura {selectedViatura.numero} — {selectedViatura.modelo}</h3>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 text-sm">
            {[["Placa", selectedViatura.placa], ["Unidade", selectedViatura.unidade], ["Velocidade", `${selectedViatura.velocidade} km/h`], ["KM", selectedViatura.km.toLocaleString("pt-BR")], ["Última atualiz.", lastUpdate.toLocaleTimeString("pt-BR")]].map(([k, v]) => (
              <div key={k}>
                <p className="text-xs text-muted-foreground mb-0.5">{k}</p>
                <p className="text-foreground font-medium mono text-xs" style={{ fontFamily: "DM Mono, monospace" }}>{v}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
