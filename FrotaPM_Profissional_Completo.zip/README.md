# FrotaPM Profissional
Arquitetura sugerida:
- Front-end: HTML/CSS/JavaScript (PWA)
- Back-end: Node.js + Express
- Banco: PostgreSQL
- OpenStreetMap + Leaflet
- WebSocket para rastreamento em tempo real
- Relatórios PDF e Excel
- Controle de usuários e permissões
