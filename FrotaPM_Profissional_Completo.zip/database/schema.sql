
CREATE TABLE viaturas(
 id SERIAL PRIMARY KEY,
 numero VARCHAR(20),
 placa VARCHAR(20),
 modelo VARCHAR(100),
 status VARCHAR(30)
);
CREATE TABLE manutencoes(
 id SERIAL PRIMARY KEY,
 viatura_id INT,
 descricao TEXT,
 custo NUMERIC,
 data_abertura TIMESTAMP
);
